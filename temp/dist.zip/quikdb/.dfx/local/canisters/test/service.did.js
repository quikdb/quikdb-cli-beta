export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    'testCreateSchema' : IDL.Func([], [IDL.Text], []),
    'testDeleteData' : IDL.Func([], [IDL.Text], []),
    'testInsertData' : IDL.Func([], [IDL.Bool], []),
    'testQueryByIndex' : IDL.Func([], [IDL.Bool], []),
    'testQuerySavedData' : IDL.Func([], [IDL.Bool], []),
    'testSearchByIndex' : IDL.Func([], [IDL.Text], []),
    'testSearchByMultipleFields' : IDL.Func([], [IDL.Text], []),
    'testUpdateData' : IDL.Func([], [IDL.Text], []),
  });
};
export const init = ({ IDL }) => { return []; };
